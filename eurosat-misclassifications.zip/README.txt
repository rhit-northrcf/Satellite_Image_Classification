Earth, Classified -- real model misclassifications.
Send this ZIP to ChatGPT to wire the 5 cards into the website.
Source: held-out split from D:\Working Directories\Deep Learning Workspace\ClassProject\EuroSATallBands\test.csv
Scanned: 2759; errors found: 95
Images are 13-band originals + RGB previews. Heatmaps are class-specific Grad-CAM overlays.
Softmax probabilities are model scores, not necessarily calibrated confidence.

/* Actual predictions from the uploaded 96.6%Acc.pth checkpoint.
   All 30 images are separate from the original 30-image gallery.
   Preview RGB = Sentinel-2 B04/B03/B02 with per-image 2–98% stretch. */
window.MISCLASSIFIED_EXAMPLES = [
  {
    "image": "assets/misclassified/misclassified-01.webp",
    "true_class": "Industrial",
    "predicted_class": "Residential",
    "confidence": 0.838081,
    "source": "Industrial_1932.tif",
    "note": "The model predicted residential, suggesting that built-up surfaces and dense development can overlap visually."
  },
  {
    "image": "assets/misclassified/misclassified-02.webp",
    "true_class": "Highway",
    "predicted_class": "River",
    "confidence": 0.907848,
    "source": "Highway_2496.tif",
    "note": "A linear corridor with water-like spectral and visual patterns may make this highway scene resemble a river."
  },
  {
    "image": "assets/misclassified/misclassified-03.webp",
    "true_class": "Pasture",
    "predicted_class": "HerbaceousVegetation",
    "confidence": 0.895514,
    "source": "Pasture_28.tif",
    "note": "Pasture and herbaceous vegetation can share broad, continuous vegetation patterns, making their boundary difficult to distinguish."
  },
  {
    "image": "assets/misclassified/misclassified-04.webp",
    "true_class": "Highway",
    "predicted_class": "PermanentCrop",
    "confidence": 0.966273,
    "source": "Highway_1020.tif",
    "note": "The model interpreted this highway scene as permanent cropland, illustrating how surrounding field patterns can influence a scene-level prediction."
  },
  {
    "image": "assets/misclassified/misclassified-05.webp",
    "true_class": "HerbaceousVegetation",
    "predicted_class": "Forest",
    "confidence": 0.790859,
    "source": "HerbaceousVegetation_1651.tif",
    "note": "The model predicted forest; differences in vegetation density and texture can be subtle in a small satellite patch."
  }
];
window.CLASSIFIER_EXAMPLES = [
  {
    "image": "assets/classification-challenge/challenge-01.webp",
    "true_class": "HerbaceousVegetation",
    "predicted_class": "HerbaceousVegetation",
    "confidence": 0.999155,
    "source": "HerbaceousVegetation_1336.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-02.webp",
    "true_class": "Highway",
    "predicted_class": "Highway",
    "confidence": 0.984741,
    "source": "Highway_2106.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-03.webp",
    "true_class": "Forest",
    "predicted_class": "Forest",
    "confidence": 0.999505,
    "source": "Forest_1302.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-04.webp",
    "true_class": "Residential",
    "predicted_class": "Residential",
    "confidence": 0.999977,
    "source": "Residential_650.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-05.webp",
    "true_class": "Forest",
    "predicted_class": "Forest",
    "confidence": 0.999999,
    "source": "Forest_2183.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-06.webp",
    "true_class": "Industrial",
    "predicted_class": "Industrial",
    "confidence": 0.999897,
    "source": "Industrial_701.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-07.webp",
    "true_class": "River",
    "predicted_class": "River",
    "confidence": 0.999993,
    "source": "River_1018.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-08.webp",
    "true_class": "Forest",
    "predicted_class": "Forest",
    "confidence": 0.999996,
    "source": "Forest_130.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-09.webp",
    "true_class": "PermanentCrop",
    "predicted_class": "PermanentCrop",
    "confidence": 0.999969,
    "source": "PermanentCrop_1307.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-10.webp",
    "true_class": "Pasture",
    "predicted_class": "AnnualCrop",
    "confidence": 0.814737,
    "source": "Pasture_1560.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-11.webp",
    "true_class": "Highway",
    "predicted_class": "Highway",
    "confidence": 0.974878,
    "source": "Highway_706.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-12.webp",
    "true_class": "Highway",
    "predicted_class": "River",
    "confidence": 0.647919,
    "source": "Highway_2089.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-13.webp",
    "true_class": "PermanentCrop",
    "predicted_class": "PermanentCrop",
    "confidence": 0.999703,
    "source": "PermanentCrop_249.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-14.webp",
    "true_class": "Residential",
    "predicted_class": "Residential",
    "confidence": 0.999969,
    "source": "Residential_548.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-15.webp",
    "true_class": "AnnualCrop",
    "predicted_class": "AnnualCrop",
    "confidence": 0.878737,
    "source": "AnnualCrop_2233.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-16.webp",
    "true_class": "SeaLake",
    "predicted_class": "SeaLake",
    "confidence": 1.0,
    "source": "SeaLake_2631.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-17.webp",
    "true_class": "HerbaceousVegetation",
    "predicted_class": "HerbaceousVegetation",
    "confidence": 0.999886,
    "source": "HerbaceousVegetation_516.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-18.webp",
    "true_class": "SeaLake",
    "predicted_class": "SeaLake",
    "confidence": 0.999998,
    "source": "SeaLake_2138.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-19.webp",
    "true_class": "SeaLake",
    "predicted_class": "SeaLake",
    "confidence": 1.0,
    "source": "SeaLake_964.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-20.webp",
    "true_class": "Pasture",
    "predicted_class": "Pasture",
    "confidence": 0.999997,
    "source": "Pasture_1523.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-21.webp",
    "true_class": "Industrial",
    "predicted_class": "Industrial",
    "confidence": 0.999959,
    "source": "Industrial_1152.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-22.webp",
    "true_class": "AnnualCrop",
    "predicted_class": "AnnualCrop",
    "confidence": 0.999432,
    "source": "AnnualCrop_265.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-23.webp",
    "true_class": "PermanentCrop",
    "predicted_class": "PermanentCrop",
    "confidence": 0.764113,
    "source": "PermanentCrop_2271.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-24.webp",
    "true_class": "Industrial",
    "predicted_class": "Industrial",
    "confidence": 0.99913,
    "source": "Industrial_1874.tif"
  },
  {
    "image": "assets/classification-challenge/challenge-25.webp",
    "true_class": "River",
    "predicted_class": "River",
    "confidence": 1.0,
    "source": "River_1359.tif"
  }
];

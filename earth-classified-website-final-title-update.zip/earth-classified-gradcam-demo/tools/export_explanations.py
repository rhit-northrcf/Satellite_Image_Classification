#!/usr/bin/env python3
"""Precompute class probabilities and Grad-CAM overlays for the existing gallery.

Run this after installing the dependencies, with the *same* trained checkpoint,
normalization statistics, and 13-band source TIFFs used for training.

Example:
  python tools/export_explanations.py \
    --eurosat-root ../EuroSATallBands \
    --checkpoint '../Model State Archives/96.6%Acc.pth' \
    --stats ../normalization_stats.txt

Produces explanations.js and assets/gradcam/*.png in the website folder.
This avoids the need for a server/GPU when presenting the static website.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import rasterio
import torch
import torch.nn as nn
from PIL import Image
from torchvision import models
import cv2

CLASS_NAMES = [
    "AnnualCrop", "Forest", "HerbaceousVegetation", "Highway", "Industrial",
    "Pasture", "PermanentCrop", "Residential", "River", "SeaLake",
]

class SatelliteImageClassifier(nn.Module):
    """Matches the encoder and three fully connected layers in ResNetModel(8).ipynb."""
    def __init__(self):
        super().__init__()
        self.encoder = models.resnet50(weights=None)  # No network download needed
        self.encoder.conv1 = nn.Conv2d(13, 64, kernel_size=7, stride=2,
                                       padding=3, bias=False)
        self.encoder.fc = nn.Identity()
        self.layer1 = nn.Linear(2048, 256)
        self.layer2 = nn.Linear(256, 64)
        self.layer3 = nn.Linear(64, 10)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.encoder(x)
        return self.layer3(self.relu(self.layer2(self.relu(self.layer1(x)))))


def parse_args():
    default_site = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site", type=Path, default=default_site,
                        help="Website directory (default: directory above this script)")
    parser.add_argument("--eurosat-root", type=Path, required=True,
                        help="Directory containing class-name folders of 13-band .tif files")
    parser.add_argument("--checkpoint", type=Path, required=True,
                        help="The final 96.6%%Acc.pth state_dict checkpoint")
    parser.add_argument("--stats", type=Path, required=True,
                        help="Original 13-row normalization_stats.txt used at training time")
    parser.add_argument("--top-cams", type=int, default=3,
                        help="Number of top-scoring classes with separate heatmaps (default: 3)")
    parser.add_argument("--layer", choices=["layer3", "layer4"], default="layer3",
                        help="Layer3 is more spatially detailed for 64x64 EuroSAT patches")
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    return parser.parse_args()


def main():
    args = parse_args()
    site = args.site.resolve()
    manifest_path = site / "assets/eurosat-gallery/manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not 1 <= args.top_cams <= len(CLASS_NAMES):
        raise ValueError("--top-cams must be between 1 and 10")

    stats = np.loadtxt(args.stats, dtype=np.float32)
    if stats.shape != (13, 2):
        raise ValueError(f"Expected 13 mean/std rows; found shape {stats.shape}")
    means = stats[:, 0, None, None]
    stds = stats[:, 1, None, None]

    device = torch.device(
        "cuda" if (args.device == "auto" and torch.cuda.is_available())
        or args.device == "cuda" else "cpu"
    )
    model = SatelliteImageClassifier().to(device)
    state = torch.load(args.checkpoint, map_location=device, weights_only=True)
    model.load_state_dict(state, strict=True)
    model.eval()

    target_layer = getattr(model.encoder, args.layer)[-1]
    cam_dir = site / "assets/gradcam"
    cam_dir.mkdir(parents=True, exist_ok=True)
    results = {}

    # Record the activation maps for class-specific Grad-CAM from a single forward pass.
    activations = {}
    def save_activations(_module, _inputs, output):
        activations["features"] = output
    handle = target_layer.register_forward_hook(save_activations)
    try:
        for i, sample in enumerate(manifest, 1):
            original_rel = Path(sample["source_tiff"])
            if original_rel.is_absolute() or ".." in original_rel.parts:
                raise ValueError(f"Unexpected manifest TIFF path: {original_rel}")
            tiff_path = args.eurosat_root / original_rel
            preview_path = site / "assets/eurosat-gallery" / sample["image"]
            with rasterio.open(tiff_path) as reader:
                data = reader.read().astype(np.float32)
            if data.ndim != 3 or data.shape[0] != 13:
                raise ValueError(f"Expected 13-channel image: {tiff_path}, got {data.shape}")

            normalized = (data - means) / (stds + 1e-8)
            input_tensor = torch.from_numpy(normalized[None, ...].copy()).to(device)
            logits = model(input_tensor)
            probs = torch.softmax(logits.detach(), dim=1)[0].cpu().numpy()
            rankings = np.argsort(probs)[::-1]
            ranked_scores = [
                {"class_id": int(class_id), "class_name": CLASS_NAMES[class_id],
                 "probability": round(float(probs[class_id]), 8)}
                for class_id in rankings
            ]

            with Image.open(preview_path) as img:
                original_rgb = img.convert("RGB")
                rgb_float = np.asarray(original_rgb, dtype=np.float32) / 255.0

            heatmaps = {}
            for class_id in rankings[:args.top_cams]:
                class_id = int(class_id)
                # Grad-CAM needs backpropagation; don't wrap this in torch.no_grad().
                gradients = torch.autograd.grad(
                    logits[0, class_id], activations["features"], retain_graph=True
                )[0]
                features = activations["features"].detach()
                weights = gradients.mean(dim=(2, 3), keepdim=True)
                mask_tensor = torch.relu((weights * features).sum(dim=1))[0]
                mask = mask_tensor.cpu().numpy()
                mask = cv2.resize(mask, (rgb_float.shape[1], rgb_float.shape[0]),
                                  interpolation=cv2.INTER_LINEAR)
                mask = mask - mask.min()
                max_value = mask.max()
                if max_value > 1e-12:
                    mask = mask / max_value
                else:
                    mask = np.zeros_like(mask)
                heatmap = cv2.applyColorMap((mask * 255).astype(np.uint8), cv2.COLORMAP_JET)
                heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.
                overlay_rgb = np.uint8(np.clip((0.55 * rgb_float + 0.45 * heatmap) * 255, 0, 255))
                filename = f"{Path(sample['image']).stem}-class-{class_id}.png"
                Image.fromarray(overlay_rgb).save(cam_dir / filename, optimize=True)
                heatmaps[str(class_id)] = "assets/gradcam/" + filename

            results[sample["image"]] = {
                "source_tiff": sample["source_tiff"],
                "true_class": sample["class_name"],
                "predicted_class": CLASS_NAMES[int(rankings[0])],
                "predicted_class_id": int(rankings[0]),
                "scores": ranked_scores,
                "heatmaps": heatmaps,
            }
            print(f"[{i:02}/{len(manifest)}] {sample['image']}: "
                  f"{CLASS_NAMES[rankings[0]]} {probs[rankings[0]]:.2%}", flush=True)

    finally:
        handle.remove()

    output = site / "explanations.js"
    output.write_text(
        "/* Generated from the trained model; do not edit scores by hand. */\n"
        "window.EUROSAT_EXPLANATIONS = "
        + json.dumps(results, indent=2, ensure_ascii=False) + ";\n",
        encoding="utf-8",
    )
    print(f"Export complete: {output} plus {len(results)} sets of heatmaps in {cam_dir}")

if __name__ == "__main__":
    main()
